# Depth Lock — Android starter project

## What this prototype does
- Selects a background image and a foreground image (transparent PNG recommended).
- Composites the foreground over a sample clock preview to demonstrate a depth-style layout.
- Lets you adjust foreground scale and vertical position.
- Saves the composed PNG and requests Android to set it as the lock-screen wallpaper.

## Important limitation
This is a working starter project, not a Samsung Good Lock module. Third-party apps cannot reliably control or replace One UI's system lock-screen clock layering/Adaptive Clock behavior. The clock in the preview is only a visual guide; it is not embedded as the real system clock. The exported wallpaper is a flattened image.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync (Android Gradle Plugin 8.7.3; JDK 17 recommended).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the APK on the Galaxy Tab A9+ and test lock-screen wallpaper setting.

Target: Android 8+; compile/target SDK 35. Tested build is not supplied because this environment does not have the Android SDK/Gradle build toolchain.
