package com.depthlock.app;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;

public class MainActivity extends Activity {
    private static final int PICK_BG = 10, PICK_FG = 11;
    private Bitmap background, foreground, rendered;
    private ImageView preview;
    private SeekBar scaleBar, yBar;
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private TextView label(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(0xFFF4F3FF);
        t.setPadding(dp(2), dp(8), dp(2), dp(8));
        return t;
    }

    private Button button(String text, Runnable action) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false);
        b.setOnClickListener(v -> action.run()); return b;
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(14), dp(18), dp(14));
        page.setBackgroundColor(0xFF10111A);

        page.addView(label("DEPTH LOCK", 25));
        page.addView(label("صمّم خلفية بطبقتين وجرّب تأثير العمق", 15));

        preview = new ImageView(this);
        preview.setBackgroundColor(0xFF242638);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, 0, 1f);
        pp.setMargins(0, dp(10), 0, dp(10));
        page.addView(preview, pp);

        page.addView(button("اختيار الخلفية", () -> pick(PICK_BG)));
        page.addView(button("اختيار العنصر الأمامي (يفضّل PNG شفاف)", () -> pick(PICK_FG)));

        page.addView(label("حجم العنصر الأمامي", 14));
        scaleBar = new SeekBar(this); scaleBar.setMax(150); scaleBar.setProgress(100);
        page.addView(scaleBar);

        page.addView(label("موضع العنصر لأعلى / لأسفل", 14));
        yBar = new SeekBar(this); yBar.setMax(100); yBar.setProgress(50);
        page.addView(yBar);

        page.addView(button("معاينة التصميم", this::render));
        page.addView(button("حفظ الصورة في المعرض", this::saveImage));
        page.addView(button("تعيين كخلفية شاشة القفل", this::setLockWallpaper));
        status = label("ابدأ باختيار صورتين.", 13);
        page.addView(status);

        scaleBar.setOnSeekBarChangeListener(listener());
        yBar.setOnSeekBarChangeListener(listener());
        setContentView(page);
    }

    private SeekBar.OnSeekBarChangeListener listener() {
        return new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { if (u && background != null) render(); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        };
    }

    private void pick(int code) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, code);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        try (InputStream in = getContentResolver().openInputStream(data.getData())) {
            Bitmap b = BitmapFactory.decodeStream(in);
            if (b == null) throw new Exception("تعذّر قراءة الصورة");
            if (req == PICK_BG) background = b;
            else if (req == PICK_FG) foreground = b;
            status.setText(req == PICK_BG ? "تم اختيار الخلفية." : "تم اختيار العنصر الأمامي.");
            render();
        } catch (Exception e) {
            Toast.makeText(this, "تعذّر فتح الصورة", Toast.LENGTH_SHORT).show();
        }
    }

    private void render() {
        if (background == null) {
            Toast.makeText(this, "اختَر الخلفية أولاً", Toast.LENGTH_SHORT).show(); return;
        }
        int w = background.getWidth(), h = background.getHeight();
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        c.drawBitmap(background, 0, 0, p);

        // Clock-like preview marker to demonstrate foreground overlap.
        Paint clock = new Paint(Paint.ANTI_ALIAS_FLAG);
        clock.setColor(0xCCFFFFFF); clock.setTextSize(Math.max(42, w * .11f));
        c.drawText("10:08", w * .08f, h * .24f, clock);

        if (foreground != null) {
            float factor = (scaleBar.getProgress() <= 0 ? 1 : scaleBar.getProgress()) / 100f;
            float targetW = w * .72f * factor;
            float ratio = Math.min(targetW / foreground.getWidth(), (h * .78f) / foreground.getHeight());
            float dw = foreground.getWidth() * ratio, dh = foreground.getHeight() * ratio;
            float left = (w - dw) / 2f;
            float top = (h - dh) * (yBar.getProgress() / 100f);
            c.drawBitmap(foreground, null, new RectF(left, top, left + dw, top + dh), p);
        }
        rendered = out;
        preview.setImageBitmap(rendered);
        status.setText("المعاينة جاهزة. العنصر الأمامي يُرسم فوق الساعة كتجربة بصرية.");
    }

    private void saveImage() {
        if (rendered == null) render();
        if (rendered == null) return;
        try {
            android.content.ContentValues v = new android.content.ContentValues();
            v.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "DepthLock-" + System.currentTimeMillis() + ".png");
            v.put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png");
            v.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DepthLock");
            Uri uri = getContentResolver().insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new Exception("storage");
            try (java.io.OutputStream os = getContentResolver().openOutputStream(uri)) {
                rendered.compress(Bitmap.CompressFormat.PNG, 100, os);
            }
            status.setText("تم حفظ الصورة في Pictures/DepthLock.");
        } catch (Exception e) { Toast.makeText(this, "فشل حفظ الصورة", Toast.LENGTH_SHORT).show(); }
    }

    private void setLockWallpaper() {
        if (rendered == null) render();
        if (rendered == null) return;
        try {
            WallpaperManager.getInstance(this).setBitmap(rendered, null, true, WallpaperManager.FLAG_LOCK);
            status.setText("تم إرسال الصورة كخلفية لشاشة القفل.");
        } catch (Exception e) {
            Toast.makeText(this, "لم يستطع النظام تعيين خلفية القفل", Toast.LENGTH_LONG).show();
        }
    }
}
